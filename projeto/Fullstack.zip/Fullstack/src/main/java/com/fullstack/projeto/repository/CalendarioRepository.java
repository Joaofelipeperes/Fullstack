package com.fullstack.projeto.repository;
package com.fullstack.projeto.repository;
package com.fullstack.projeto;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CalendarioRepository extends JpaRepository<Calendario, Long> {
}
